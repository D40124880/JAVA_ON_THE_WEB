package com.codingdojo.models;

public interface Pet {
	
	String showAffection();
}
